
python -m venv env

# Activate the virtual environment
& "$targetDir\env\Scripts\Activate"

# Install dependencies
pip install asgiref Django ldap3 pyasn1 sqlparse tzdata




